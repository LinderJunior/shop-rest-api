package com.linder.shop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.linder.shop.dto.PessoaClienteRequestDTO;
import com.linder.shop.model.Pessoa;
import com.linder.shop.service.PessoaClienteService;
import com.linder.shop.service.PessoaGerenciamentoService;
import com.linder.shop.service.PessoaService;

@RestController
@RequestMapping("/pessoa-gerenciamento")
public class PessoaGerenciamentoController {

	@Autowired
	private PessoaGerenciamentoService pessoaGerenciamentoService;
		
	//save 
	@PostMapping("/senha-codigo")
	public String recuperarCodigo(@RequestBody Pessoa pessoa) {	
		return pessoaGerenciamentoService.solicitarCodigo(pessoa.getEmail());
	}
	
	//save 
	@PostMapping("/senha-alterar")
	public String alterarSenha(@RequestBody Pessoa pessoa) {	
		return pessoaGerenciamentoService.alterarSenha(pessoa);
	}
	
	
}
