package com.linder.shop.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.linder.shop.model.PermissaoPessoa;

public interface PermissaoPessoaRepository extends JpaRepository<PermissaoPessoa, Long> {

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
