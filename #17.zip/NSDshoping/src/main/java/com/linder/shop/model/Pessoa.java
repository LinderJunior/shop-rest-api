package com.linder.shop.model;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name="pessoa")
public class Pessoa {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String cpf;
	
	private String email;
	
	private String codigoRecuperacaoSenha;
	
	@Temporal(TemporalType.TIMESTAMP)
	private Date dataEnvioCodigo;
	
	private String senha;
	
	private String endereco;
	
	private String cep;
	
	private Date  dataCriacao;

	@ManyToOne
	@JoinColumn(name="cidade_id", nullable = false)
	private Cidade cidade;
	
	//Nao gerar o set de permissaoPessoa
	//orphanRemoval - se um elemento nao existir na lista mas existir no banco e' pra apagar no banco. Passar a lista sem um determinado elemento
	//cascade - permissitir. Se atualizar pessoa, tambem atualizar a pessoa;
	
	/*
	@JsonIgnore
	@OneToMany(mappedBy = "pessoa", orphanRemoval = true, cascade= {CascadeType.PERSIST, CascadeType.MERGE})
	private List<PermissaoPessoa>permissaoPessoa;
	/*	
	public List<PermissaoPessoa> getPermissaoPessoa() {
		return permissaoPessoa;
	}
	
	//iteracao; chamadado assi que o crontrole receber uma requisicao
	public void setPermissaoPessoa(List<PermissaoPessoa> pp) {
		for(PermissaoPessoa p:pp) {
			p.setPessoa(this);
		}
		this.permissaoPessoa=pp;
	}
	*/

	@OneToMany(mappedBy = "pessoa", orphanRemoval = true, cascade= {CascadeType.PERSIST, CascadeType.MERGE})
	@JsonIgnore
	private List<PermissaoPessoa>permissaoPessoas;
	
	public List<PermissaoPessoa> getPermissaoPessoa() {
		return permissaoPessoas;
	}
	
	
	//iteracao; chamadado assi que o crontrole receber uma requisicao
	public void setPermissaoPessoa(List<PermissaoPessoa> pp) {
		for(PermissaoPessoa p:pp) {
			p.setPessoa(this);
		}
		this.permissaoPessoas=pp;
	}
	

	public String getCodigoRecuperacaoSenha() {
		return codigoRecuperacaoSenha;
	}


	public void setCodigoRecuperacaoSenha(String codigoRecuperacaoSenha) {
		this.codigoRecuperacaoSenha = codigoRecuperacaoSenha;
	}


	public Date getDataEnvioCodigo() {
		return dataEnvioCodigo;
	}


	public void setDataEnvioCodigo(Date dataEnvioCodigo) {
		this.dataEnvioCodigo = dataEnvioCodigo;
	}


	public List<PermissaoPessoa> getPermissaoPessoas() {
		return permissaoPessoas;
	}


	public void setPermissaoPessoas(List<PermissaoPessoa> permissaoPessoas) {
		this.permissaoPessoas = permissaoPessoas;
	}


	public Cidade getCidade() {
		return cidade;
	}

	public void setCidade(Cidade cidade) {
		this.cidade = cidade;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public Date getDataCriacao() {
		return dataCriacao;
	}

	public void setDataCriacao(Date dataCriacao) {
		this.dataCriacao = dataCriacao;
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pessoa other = (Pessoa) obj;
		return Objects.equals(id, other.id);
	}

	public Pessoa() {
		super();
		// TODO Auto-generated constructor stub
	}
}
