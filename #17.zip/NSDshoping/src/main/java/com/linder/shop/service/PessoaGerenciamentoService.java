package com.linder.shop.service;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.linder.shop.dto.PessoaClienteRequestDTO;
import com.linder.shop.model.Cidade;
import com.linder.shop.model.Pessoa;
import com.linder.shop.repository.PermissaoRepository;
import com.linder.shop.repository.PessoaClienteRepository;
import com.linder.shop.repository.PessoaRepository;

@Service
public class PessoaGerenciamentoService {
	
	@Autowired
	private PessoaRepository pessoaRepository;
	
	
	@Autowired
	private PermissaoRepository permissaoRepository;
	
	@Autowired
	private EmailService emailService;
	
	//save
	public String solicitarCodigo(String email) {
		Pessoa pessoa = pessoaRepository.findByEmail(email);
		pessoa.setCodigoRecuperacaoSenha(getCodigoRecuperacaoSenha(pessoa.getId()));
		pessoa.setDataEnvioCodigo(new Date());
		pessoaRepository.save(pessoa);
		emailService.enviarEmailTexto(pessoa.getEmail(), "Codigo de Recuperacao ", "Ola, o seu codigo para recuperacao de senha e' o seguinte: " +pessoa.getCodigoRecuperacaoSenha());
		
		return "Codigo enviado!";
	}

	
	public String alterarSenha(Pessoa pessoa) {
		
		Pessoa pessoaBanco = pessoaRepository.findByEmailAndCodigoRecuperacaoSenha(pessoa.getEmail(), pessoa.getCodigoRecuperacaoSenha());
		
		Date diferenca = new Date(new Date().getTime()-pessoaBanco.getDataEnvioCodigo().getTime());
		
		if(diferenca.getTime()/1000<900) {
			pessoaBanco.setSenha(pessoa.getSenha());
			pessoaBanco.setCodigoRecuperacaoSenha(null);
			pessoaRepository.save(pessoaBanco);
			return "Senha alterada com sucesso";
		}else {
			return "Tempo expirado, solicite um novo codigo";
		}
		
		
		
		
		
	}
	

	
	private String getCodigoRecuperacaoSenha(Long id) {
		DateFormat format = new SimpleDateFormat("ddMMyyyyHHmmssmm");
		return format.format(new Date())+id;
	}
	
	
	
	
	
}
