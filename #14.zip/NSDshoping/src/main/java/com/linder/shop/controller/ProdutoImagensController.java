package com.linder.shop.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.linder.shop.model.ProdutoImagens;
import com.linder.shop.repository.ProdutoImagensRepository;
import com.linder.shop.service.ProdutoImagensService;

@RestController
@RequestMapping("/imagem")
public class ProdutoImagensController {
	
	@Autowired
	private ProdutoImagensService produtoImagensService;
	
	@Autowired
	private ProdutoImagensRepository produtoImagensRepository;
	
	@GetMapping("/imagens")
	public List<ProdutoImagens>findAll(){
		return produtoImagensService.findAll();
	}
	//save
	@PostMapping("/save")
	public ProdutoImagens save(@RequestParam("idProduto") Long idProduto, @RequestParam("file") MultipartFile file) {
		return produtoImagensService.save(idProduto, file);
		
	}
	//update
	@PutMapping("/update")
	public ProdutoImagens update(@RequestParam("idProduto") Long idProduto, @RequestParam("file") MultipartFile file) {
		return produtoImagensService.save(idProduto, file);
		
	}
	
	//delete
	@DeleteMapping("/{id}")
	public void delete(@PathVariable("id") Long id) {
		ProdutoImagens objecto = produtoImagensRepository.findById(id).get();
		produtoImagensRepository.delete(objecto);
	}
	

}
