package com.linder.shop.service;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.linder.shop.dto.PessoaClienteRequestDTO;
import com.linder.shop.model.Cidade;
import com.linder.shop.model.Pessoa;
import com.linder.shop.repository.PermissaoRepository;
import com.linder.shop.repository.PessoaClienteRepository;
import com.linder.shop.repository.PessoaRepository;

@Service
public class PessoaClienteService {
	
	@Autowired
	private PessoaClienteRepository pessoaRepository;
	
	@Autowired
	private PermissaoPessoaService permissaoPessoaService;
	
	@Autowired
	private PermissaoRepository permissaoRepository;
	
	//save
	public Pessoa save(PessoaClienteRequestDTO pessoaClienteRequestDTO) {
		Pessoa pessoa = new PessoaClienteRequestDTO().converter(pessoaClienteRequestDTO);	
		pessoa.setDataCriacao(new Date());
		Pessoa novaPessoa = pessoaRepository.save(pessoa);
		permissaoPessoaService.vincularPessoaPermissaoCliente(novaPessoa);
		return novaPessoa;
	}

	
	
	
	
	
}
