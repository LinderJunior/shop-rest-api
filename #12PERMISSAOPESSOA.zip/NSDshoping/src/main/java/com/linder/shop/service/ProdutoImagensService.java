package com.linder.shop.service;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

import org.apache.tomcat.jni.File;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.linder.shop.model.Produto;
import com.linder.shop.model.ProdutoImagens;
import com.linder.shop.repository.ProdutoImagensRepository;
import com.linder.shop.repository.ProdutoRepository;

import org.springframework.web.multipart.MultipartFile;

@Service
public class ProdutoImagensService {

	
	@Autowired
	private ProdutoImagensRepository produtoImagensRepository;
	
	@Autowired
	private ProdutoRepository produtoRepository;
	
	//findAll
	public List<ProdutoImagens>findAll(){
		return produtoImagensRepository.findAll();
	}
	
	//save
	public ProdutoImagens save(Long idProduto, MultipartFile file) {
		Produto produto = produtoRepository.findById(idProduto).get();
		ProdutoImagens objecto = new ProdutoImagens();
		
		
		try {
			if(!file.isEmpty()) {
				byte[] bytes = file.getBytes();
				String nomeImagem = String.valueOf(produto.getId())+file.getOriginalFilename();
				Path caminho = Paths
						.get("c:/imagens/" +nomeImagem);
				Files.write(caminho, bytes);
				objecto.setNome(nomeImagem);
			}
		}catch(IOException e) {
			e.printStackTrace();
		}
		
		objecto.setProduto(produto);;
		objecto.setDataCriacao(new Date());
		objecto = produtoImagensRepository.save(objecto);
		return objecto;
	}
	//update
	public ProdutoImagens update(ProdutoImagens produtoImagens) {
		produtoImagens.setDataCriacao(new Date());
		ProdutoImagens novoProdutoImagens = produtoImagensRepository.save(produtoImagens);
		return novoProdutoImagens;
	}
	//delete
	public void delete(Long id) {
		ProdutoImagens produtoImagens = produtoImagensRepository.findById(id).get();
		produtoImagensRepository.delete(produtoImagens);
	}
	
	
	
	
	
	
	
	
	
	
	
}
